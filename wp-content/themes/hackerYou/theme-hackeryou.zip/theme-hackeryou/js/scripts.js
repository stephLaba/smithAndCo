$(function(){
	//your jQuery here
});